 

import java.util.Set;
import java.util.TreeSet;
import java.lang.StringBuilder;

public class Comprador extends Utilizador{
    private Set<Imovel> favoritos;
    
    public Comprador(String email, String nome, String password, String data, String morada){
        super(email,nome,password,data,morada);
        favoritos = new TreeSet<>();
    }
    
    public Comprador(Comprador c){
        super(c.getEmail(),c.getNome(),c.getPassword(),c.getData(),c.getMorada());
        favoritos = c.getFavoritos();
    }
    
    public Comprador(){
        super();
        favoritos = new TreeSet<>();
    }
    
    public Set<Imovel> getFavoritos(){
        Set<Imovel> res = new TreeSet<>();
        for(Imovel im:favoritos){
            res.add((Imovel) im.clone());
        }
        return res;
    }
    
    public void setFavoritos(Set<Imovel> s){
        favoritos.clear();
        for(Imovel im:s){
            favoritos.add((Imovel) im.clone());
        }
    }
    
    public String toString(){
        StringBuilder s = new StringBuilder();
        for(Imovel im:favoritos){
            s.append(im.toString());
            s.append(", ");
        }
        return s.toString();
    }
    
    public boolean equals(Object o){
        
        if(o == this) return true;
        if(o == null || o.getClass() != this.getClass()) return false;
        Comprador c = (Comprador) o;
        return this.favoritos.containsAll(c.getFavoritos());
    }
    
    public Comprador clone(){
        return new Comprador(this);
    }
    
    public Utilizador copia(){
        return (Utilizador) new Comprador(this);
    }
}
