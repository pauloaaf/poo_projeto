
/**
 * Write a description of class Habitavel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Habitavel extends Imovel{
    // instance variables - replace the example below with your own
    public Habitavel(){
        super();
    }
    
    public Habitavel(String rua, double precoPedido, double precoMinimo,String estado){
        super(rua,precoPedido,precoMinimo,estado);
    }
    
    public Habitavel(Habitavel a){
        this(a.getRua(),a.getPrecoPedido(),a.getPrecoMinimo(),a.getEstado());
    }
    
    public Habitavel clone(){
        return new Habitavel(this);
    }
    
    public boolean equals(Object o){
        if(o == this) 
            return true;
        if(o == null || o.getClass() != this.getClass())
            return false;
        Habitavel h = (Habitavel) o;
        return super.equals(o);
    }
    
    public String toString(){
        return super.toString();
    }
    
    public int identificadorImovel(){
        return super.identificadorImovel();        
    }
}
