import java.util.Comparator;

public class Imovel implements Comparable<Imovel>{

    private String rua;
    private double precoPedido;
    private double precoMinimo;
    private String identificador;
    private String estado; 
    
    //Construtores
    public Imovel(String rua, double precoPedido, double precoMinimo,String estado){
        this.rua = rua;
        this.precoPedido = precoPedido;
        this.precoMinimo = precoMinimo;
        this.estado = estado;
    }
    
    public Imovel(Imovel im){
        this(im.getRua(), im.getPrecoPedido(), im.getPrecoMinimo(),im.getEstado());
    }
    
    public Imovel(){
        this("N/A",0.0,0.0,"N/A");
    }
    
    //Gets e Sets
    public String getRua() {
        return rua;
    }
    public void setRua(String rua) {
        this.rua = rua;
    }
    public double getPrecoPedido() {
        return precoPedido;
    }
    public void setPrecoPedido(double precoPedido) {
        this.precoPedido = precoPedido;
    }
    public double getPrecoMinimo() {
        return precoMinimo;
    }
    public void setPrecoMinimo(double precoMinimo) {
        this.precoMinimo = precoMinimo;
    }
    
    public String getIdentificador(){
        return identificador;
    }
    
    public void setIdentificador(String identificador){
        this.identificador = identificador;
    }
    
    public String getEstado(){
        return estado;
    }
    
    public void setEstado(String estado){
        this.estado = estado;
    }
    
    public String toString(){
        return rua+", "+precoPedido+", "+precoMinimo;
    }
    
    /*Identificador da parte comum a todos*/
    public long identificadorImovel(){
        long id = 0;
        
        //Id string;
        id += rua.hashCode();
        
        //Id precoPedido
        long p = Double.doubleToLongBits(precoPedido);
        id+= (p^(p>>>32));
        
        //Id precoMinimo
        p = Double.doubleToLongBits(precoMinimo);
        id+= (p^(p>>>32));
        
        //Id tipo
        
        return id;
        
    }
    
    public Imovel clone(){
        return new Imovel(this);
    }
    
    public boolean equals(Object o){
        if(o == this) return true;
        if(o == null || o.getClass()!= this.getClass()) return false;
        Imovel im = (Imovel) o;
        return im.getRua() == this.getRua() && im.getPrecoMinimo() == this.getPrecoMinimo() && im.getPrecoPedido() == this.getPrecoPedido();
    }
    
    public int compareTo(Imovel im){
        
        int res = 0;
        int identificador = Integer.parseInt(this.identificador);
        int imIdentificador = Integer.parseInt(im.getIdentificador());
        
        if(identificador == imIdentificador) 
            res = 0;
        else if(identificador>imIdentificador)
            res = 1;
        else if(identificador<imIdentificador)
            res = -1;
        
        return res;
    }
    
}

