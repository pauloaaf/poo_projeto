import java.util.Set;
import java.util.TreeSet;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;

public class Imoobiliaria {
    
    private boolean sessaoIniciada = false;
    private Utilizador utilizadorIniciado = null;
    private Set<Utilizador> utilizadoresRegistados;
    private Set<Imovel> imoveisRegistados;
    
    public Imoobiliaria(){
        utilizadoresRegistados = new TreeSet<>();
        imoveisRegistados = new TreeSet<>();
    }
    
    /*gets e sets*/
    public Set<Utilizador> getUtilizadoresRegistados(){
        Set<Utilizador> res = new TreeSet<>();
        for(Utilizador u:utilizadoresRegistados)
            res.add(u.clone());
        return res;
    }
    
    public void setUtilizadoresRegistados(Set<Utilizador> u){
        utilizadoresRegistados.clear();
        for(Utilizador ut:u)
            utilizadoresRegistados.add(ut.clone());
    }
    
    public Set<Imovel> getImoveisRegistados(){
        Set<Imovel> res = new TreeSet<>();
        for(Imovel im:imoveisRegistados){
            res.add(im.clone());
        }
            
        return res;
    }
    
    public void setImoveisRegistados(Set<Imovel> imoveisRegistados){
        this.imoveisRegistados.clear();
        for(Imovel im:imoveisRegistados)
            this.imoveisRegistados.add(im.clone());
   }
   
    
    public boolean getSessaoInicia() {return sessaoIniciada;}

    public void setSessaoInicia(boolean sessaoIniciada) {this.sessaoIniciada = sessaoIniciada;}
    
    /*Funçoes pdf*/
    public void registaImovel(Imovel im)
        throws ImovelExisteException,
               SemAutorizacaoException{
                     
        if(utilizadorIniciado == null)
            throw new SemAutorizacaoException("Necessario iniciar sessao!");
        if(utilizadorIniciado.getClass().getSimpleName().equals("Comprador"))
            throw new SemAutorizacaoException("Sem direitos");  
        
        if(!imoveisRegistados.add((Imovel) im.clone()))
            throw new ImovelExisteException("Imovel ja registado!");
                   
    }

    public void registaUtilizador(Utilizador utilizador)
        throws UtilizadorExistenteException{
        /*RegistaUtilizador r = new RegistaUtilizador();
        r.registar(utilizador);//RegistaUtilizador.java*/
        
        //verificar se o utilizador ja existe
        if(!utilizadoresRegistados.add(utilizador.clone()))
            throw new UtilizadorExistenteException("Este utilizador ja existe!");
    }
    
    public void iniciaSessao(String email, String password)
        throws SemAutorizacaoException{//Exceptions.java
        //Ficheiro f = new Ficheiro();
        
        for(Utilizador utilizador:utilizadoresRegistados){
            if(utilizador.getEmail().equals(email) && !utilizador.getPassword().equals(password))
                throw new SemAutorizacaoException("Password errada!");
            if(utilizador.getEmail().equals(email) && utilizador.getPassword().equals(password)){
                sessaoIniciada = true;
                utilizadorIniciado = utilizador.clone();
                return;
            }
        }
        throw new SemAutorizacaoException("Utilizador nao existe!");
    }
    
    public void fechaSessao(){
        sessaoIniciada = false;
        utilizadorIniciado = null;
    }
    
    /*public List<Consulta > getConsultas ()
        throws SemAutorizacaoException{}*/
        
    public void setEstado (String idImovel, String estado)
        throws ImovelInexistenteException,
               SemAutorizacaoException,
               EstadoInvalidoException{
        
        if(utilizadorIniciado == null)
            throw new SemAutorizacaoException("Necessario iniciar sessao!");
        if(utilizadorIniciado.getClass().getSimpleName().equals("Comprador"))
            throw new SemAutorizacaoException("Sem direitos"); 
        
        if(!estado.equals("Venda") || !estado.equals("Reversado") || !estado.equals("Vendido"))
            throw new EstadoInvalidoException("Estado invalido!");
                
        for(Imovel im:imoveisRegistados){
            if(im.getIdentificador().equals(idImovel)){
                im.setEstado(estado);
                return;
            }
        }
        throw new ImovelInexistenteException("Imovel inexistente!");
    }
    
    /*
    public List <Imovel> getImovel ( String classe , int preco ) {
        List<Imovel> lista = new ArrayList<>();
        if(imoveisRegistados.isEmpty()) return lista;
        
        for(Imovel i : imoveisRegistados) {
            if(classe.equals(i.getTipoImovel())){
                if(i.getPrecoPedido()<=preco) {
                    lista.add(i.clone());
                }
            }
        }
        return lista;
    }*/
    
    /*Lista de todos os imoveis habitaveis, ate um certo preço*/
    public List<Habitavel> getHabitaveis(int preco){
        List<Habitavel> res = new ArrayList<>();
        
        for(Imovel im:imoveisRegistados){
            if(im instanceof Habitavel && im.getPrecoPedido() <= preco){
                res.add((Habitavel) im.clone());
            }
        }
        return res;
    }
    
    public void initApp(){
        //RegistaUtilizador r = new RegistaUtilizador();//RegistaUtilizador.java
        //Utilizador utilizador = r.recolheDados();
        
    }
}
