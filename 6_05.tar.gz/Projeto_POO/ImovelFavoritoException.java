
/**
 * Write a description of class ImovelJaFavoritoException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ImovelFavoritoException extends Exception{
    // instance variables - replace the example below with your own
    private String s;
    
    public ImovelFavoritoException(String s){
        this.s = s;
    }
    
    public String toString(){
        return s;
    }
}
