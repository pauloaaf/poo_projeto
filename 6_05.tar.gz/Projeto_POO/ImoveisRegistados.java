 

import java.io.File;
import java.util.ArrayList;

public class ImoveisRegistados {
	ArrayList<? extends Imovel> imoveis = new ArrayList<Imovel>();
	
	public ImoveisRegistados() {
		imoveis = new ArrayList<Imovel>();
	}	
	
}
