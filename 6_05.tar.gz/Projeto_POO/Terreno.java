 

public class Terreno extends Imovel{
    
    private double areaConstrucao;
    private boolean tipoConstrucao; // True para habita�ao e armazem, False apenas para armazem 
    private double diametro; // milimetros
    private double kwh; // kilowats da rede eletrica
    private boolean redeEletrica, redeEsgotos;
    
     //construtor terreno
    public Terreno(String rua, double precoPedido, double precoMinimo, EstadoImovel estado, double areaConstrucao
                  ,boolean tipoConstrucao, double diametro, double kwh, boolean redeEletrica, boolean redeEsgotos) {
        super(rua,precoPedido,precoMinimo,estado);
        this.areaConstrucao = areaConstrucao;
        this.tipoConstrucao = tipoConstrucao;
        this.diametro = diametro;
        this.kwh = kwh;
        this.redeEletrica = redeEletrica;
        this.redeEsgotos = redeEsgotos;
        geraIdentificador();
    }
    
    public Terreno(Terreno t) {
        this(t.getRua(),t.getPrecoPedido(),t.getPrecoMinimo(), t.getEstado(), t.getAreaConstrucao(),t.getTipoConstrucao()
                ,t.getDiametro(),t.getKwh(),t.getRedeEletrica(),t.getRedeEsgotos());
    }    
    
    public Terreno(){
        super();
        this.areaConstrucao = 0.0;
        this.tipoConstrucao = false;
        this.diametro = 0.0;
        this.kwh = 0.0;
        this.redeEletrica = false;
        this.redeEsgotos = false;
        geraIdentificador();
    }
    
    //get e set terreno

    public double getAreaConstrucao() {
        return areaConstrucao;
    }

    public void setAreaConstrucao(double areaConstrucao) {
        this.areaConstrucao = areaConstrucao;
    }

    public boolean getTipoConstrucao() {
        return tipoConstrucao;
    }

    public void setTipoConstrucao(boolean tipoConstrucao) {
        this.tipoConstrucao = tipoConstrucao;
    }

    public double getDiametro() {
        return diametro;
    }

    public void setDiametro(double diametro) {
        this.diametro = diametro;
    }

    public double getKwh() {
        return kwh;
    }

    public void setKwh(double kwh) {
        this.kwh = kwh;
    }

    public boolean getRedeEletrica() {
        return redeEletrica;
    }

    public void setRedeEletrica(boolean redeEletrica) {
        this.redeEletrica = redeEletrica;
    }

    public boolean getRedeEsgotos() {
        return redeEsgotos;
    }

    public void setRedeEsgotos(boolean redeEsgotos) {
        this.redeEsgotos = redeEsgotos;
    }
    
    public Terreno clone(){
        return new Terreno(this);
    }
    
    public boolean equals(Object o){
        if(o == this) return true;
        if(o == null || o.getClass()!= this.getClass()) return false;
        Terreno t = (Terreno) o;
        
        return super.equals(o);
    }
    
    public String toString(){
        StringBuilder str = new StringBuilder();
        
        str.append(super.toString());
        str.append(Double.toString(areaConstrucao) + ", ");
        str.append(String.valueOf(tipoConstrucao) + ", ");
        str.append(Double.toString(diametro) + ", ");
        str.append(Double.toString(kwh) + ", ");
        str.append(String.valueOf(redeEletrica) + ", ");
        str.append(String.valueOf(redeEsgotos));
        
        return str.toString();
    }
    
    public void  geraIdentificador(){
        
        int id = super.identificadorImovel();
        
        //Id para Classe
        
        id+=this.getClass().getSimpleName().hashCode();
        
        //Id areaConstrucao
        int p = (int) Double.doubleToLongBits(areaConstrucao);
        id+= (p^(p>>>32));
        
        //Id tipoConstrucao
        id+= (tipoConstrucao ? 0:1);
        
        //id diametro
        p = (int) Double.doubleToLongBits(diametro);
        id+= (p^(p>>>32));
        
        //id kwh
        p = (int) Double.doubleToLongBits(kwh);
        id+=(p^(p>>>32));
        
        //id Rede eletrica
        
        id+=(redeEletrica ? 0:1);
        
        //id Esgotos
        
        id+=(redeEsgotos ? 0:1);
        
        super.setIdentificador(id + "");
    }
    
}

