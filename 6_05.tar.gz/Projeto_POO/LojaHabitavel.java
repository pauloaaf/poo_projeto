
/**
 * Write a description of class LojaHabitavel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LojaHabitavel extends Loja implements Habitavel{
    private String tipo;
    private double areaTotal;
    private int quartos;
    private int wc;
    private int porta;
    private int andar;
    private boolean garagem;

    //construtor apartamento

    public LojaHabitavel (){
        super();
        this.tipo = "N/A";
        this.areaTotal = 0;
        this.andar = 0;
        this.wc = 0;
        this.quartos = 0;
        this.porta = 0;
        this.garagem = false;
        geraIdentificador();
    }

    public LojaHabitavel(String rua, double precoPedido, double precoMinimo, EstadoImovel estado, double area, boolean wc, String tipoNegocio, int porta
                         ,String tipo, double areaTotal, int quartos, int qWc, int andar, boolean garagem) {
        super(rua,precoPedido,precoMinimo,estado,area,wc,tipoNegocio,porta);
        this.tipo = tipo;
        this.areaTotal = areaTotal;
        this.quartos = quartos;
        this.wc = qWc;
        this.porta = porta;
        this.andar = andar;
        this.garagem = garagem;
        geraIdentificador();
    }

    public LojaHabitavel(LojaHabitavel a) {
        this(a.getRua(),a.getPrecoPedido(),a.getPrecoMinimo(),a.getEstado(),a.getArea(), a.getWc(),a.getTipoNegocio(), a.getPorta()
                ,a.getTipo(),a.getAreaTotal(),a.getQuartos(),a.getQuantosWC(),a.getAndar(),a.getGaragem());
    }

    //get e set apartamento
    public String getTipo(){
        return tipo;
    }

    public void setTipo(String tipo){
        this.tipo = tipo;
    }
    public double getAreaTotal() {
        return areaTotal;
    }

    public void setAreaTotal(double areaTotal) {
        this.areaTotal = areaTotal;
    }

    public int getQuartos() {
        return quartos;
    }

    public void setQuartos(int quartos) {
        this.quartos = quartos;
    }

    public int getQuantosWC() {
        return wc;
    }

    public void setQuantosWC(int wc) {
        this.wc = wc;
    }

    public int getPorta() {
        return porta;
    }

    public void setPorta(int porta) {
        this.porta = porta;
    }

    public int getAndar() {
        return andar;
    }

    public void setAndar(int andar) {
        this.andar = andar;
    }

    public boolean getGaragem() {
        return garagem;
    }

    public void setGaragem(boolean garagem) {
        this.garagem = garagem;
    }

    public LojaHabitavel clone (){
        return new LojaHabitavel(this);
    }

    public boolean equals(Object o){
        if(o == this) return true;
        if(o == null || o.getClass()!= this.getClass()) return false;
        return super.equals(o);
    }
    public String toString(){
        StringBuilder str = new StringBuilder();

        str.append(super.toString()+ ", ");
        str.append(tipo+ ", ");
        str.append(Double.toString(areaTotal)+ ", ");
        str.append(Integer.toString(quartos)+ ", ");
        str.append(String.valueOf(wc)+ ", ");
        str.append(Integer.toString(porta)+ ", ");
        str.append(Integer.toString(andar)+ ", ");
        str.append(String.valueOf(garagem));

        return str.toString();


    }
    
    public void geraIdentificador(){
        int id = super.identificadorImovel();
        
        //Id para Classe
        
        id+=this.getClass().getSimpleName().hashCode();
        
        //Id tipo

        
        //Id areaTotal
        int p = (int) Double.doubleToLongBits(areaTotal);
        id+=(p^(p>>>32));
        
        //id garagem
        
        id+= garagem ? 0:1;
        
        //Id quartos, wc, porta, andar
        
        id+= quartos+porta+wc+andar;
        
        super.setIdentificador(id + "");
    }
}
