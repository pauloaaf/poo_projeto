 

public class SemAutorizacaoException extends Exception{
	private String s;

	public SemAutorizacaoException(String s) {
		this.s=s;
	} 
	
	public SemAutorizacaoException(){
		this("Sem Autorização!");
	}

	public String toString(){return s;}
}
