

public class Apartamento extends Imovel implements Habitavel{

    private TipoApartamento tipo;
    private double areaTotal;
    private int quartos;
    private int wc;
    private int porta;
    private int andar;
    private boolean garagem;

    //construtor apartamento

    public Apartamento (){
        super();
        this.tipo = TipoApartamento.Indefinido;
        this.areaTotal = 0;
        this.andar = 0;
        this.wc = 0;
        this.quartos = 0;
        this.porta = 0;
        this.garagem = false;
        geraIdentificador();
    }

    public Apartamento(String rua, double precoPedido, double precoMinimo, EstadoImovel estado, TipoApartamento tipo, double areaTotal, int quartos, int wc, int porta
            , int andar, boolean garagem) {
        super(rua,precoPedido,precoMinimo,estado);
        this.tipo = tipo;
        this.areaTotal = areaTotal;
        this.quartos = quartos;
        this.wc = wc;
        this.porta = porta;
        this.andar = andar;
        this.garagem = garagem;
        geraIdentificador();
    }

    public Apartamento(Apartamento a) {
        this(a.getRua(),a.getPrecoPedido(),a.getPrecoMinimo(),a.getEstado(),a.getTipo(),a.getAreaTotal(),a.getQuartos(),a.getWc(),a.getPorta()
                ,a.getAndar(),a.getGaragem());
    }

    //get e set apartamento
    public TipoApartamento getTipo(){
        return tipo;
    }

    public void setTipo(TipoApartamento tipo){
        this.tipo = tipo;
    }
    public double getAreaTotal() {
        return areaTotal;
    }

    public void setAreaTotal(double areaTotal) {
        this.areaTotal = areaTotal;
    }

    public int getQuartos() {
        return quartos;
    }

    public void setQuartos(int quartos) {
        this.quartos = quartos;
    }

    public int getWc() {
        return wc;
    }

    public void setWc(int wc) {
        this.wc = wc;
    }

    public int getPorta() {
        return porta;
    }

    public void setPorta(int porta) {
        this.porta = porta;
    }

    public int getAndar() {
        return andar;
    }

    public void setAndar(int andar) {
        this.andar = andar;
    }

    public boolean getGaragem() {
        return garagem;
    }

    public void setGaragem(boolean garagem) {
        this.garagem = garagem;
    }

    public Apartamento clone (){
        return new Apartamento(this);
    }

    public boolean equals(Object o){
        if(o == this) return true;
        if(o == null || o.getClass()!= this.getClass()) return false;
        return super.equals(o);
    }
    public String toString(){
        StringBuilder str = new StringBuilder();

        str.append(super.toString()+ ", ");
        str.append(tipo+ ", ");
        str.append(Double.toString(areaTotal)+ ", ");
        str.append(Integer.toString(quartos)+ ", ");
        str.append(String.valueOf(wc)+ ", ");
        str.append(Integer.toString(porta)+ ", ");
        str.append(Integer.toString(andar)+ ", ");
        str.append(String.valueOf(garagem));

        return str.toString();


    }
    
    public void geraIdentificador(){
        int id = super.identificadorImovel();
        
        //Id para Classe
        
        id+=this.getClass().getSimpleName().hashCode();
        
        //Id tipo
        id+=tipo.hashCode();
        
        //Id areaTotal
        int p = (int) Double.doubleToLongBits(areaTotal);
        id+=(p^(p>>>32));
        
        //id garagem
        
        id+= garagem ? 0:1;
        
        //Id quartos, wc, porta, andar
        
        id+= quartos+porta+wc+andar;
        
        super.setIdentificador(id + "");
    }
}
