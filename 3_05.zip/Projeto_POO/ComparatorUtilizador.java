
/**
 * Write a description of class ComparatorUtilizador here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.Comparator;

public class ComparatorUtilizador implements Comparator<Utilizador>{
    // instance variables - replace the example below with your own
    
    public int compare(Utilizador u1,Utilizador u2){
        return u1.compareTo(u2);
    }
}
