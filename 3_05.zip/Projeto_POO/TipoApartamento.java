
/**
 * Enumeration class TipoApartamento - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum TipoApartamento{
    Simples, Duplex, Triplex, Indefinido;
}
