package projeto_poo;

import java.util.Set;
import java.util.TreeSet;
import java.lang.StringBuilder;

public class Comprador extends Utilizador{
	private Set<Imovel> favoritos;
	
	public Comprador(String email, String nome, String password, String data, String morada, int tipo){
		super(email,nome,password,data,morada,tipo);
		favoritos = new TreeSet<>();
	}
	
	public Comprador(Comprador c){
		super(c.getEmail(),c.getNome(),c.getPassword(),c.getData(),c.getMorada(),c.getTipo());
		favoritos = c.getFavoritos();
	}
	
	public Set<Imovel> getFavoritos(){
		Set<Imovel> res = new TreeSet<>();
		for(Imovel im:favoritos){
			res.add(im.clone());
		}
		return res;
	}
	
	public void setFavoritos(Set<Imovel> s){
		favoritos.clear();
		for(Imovel im:s){
			favoritos.add(im.clone());
		}
	}
	
	public String toString(){
		StringBuilder s = new StringBuilder();
		for(Imovel im:favoritos){
			s.append(im.toString());
			s.append(", ");
		}
		return s.toString();
	}
	
	public boolean equals(Object o){
		boolean igual = true;
		
		if(o == this) return true;
		if(o == null || o.getClass() != this.getClass()) return false;
		Comprador c = (Comprador) o;
		
	}
}
