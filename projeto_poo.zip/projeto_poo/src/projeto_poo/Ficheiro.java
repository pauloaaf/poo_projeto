package projeto_poo;

/**
 * Funções relacionadas com ficheiros
 */

import java.io.File;

public class Ficheiro {
	/**
	 * 
	 * @param email, para ver se já existe um ficheiro com o mesmo email
	 * @throws UtilizadorExistenteException
	 */
	public void existe(String s)
		throws UtilizadorExistenteException{
		File arquivo = new File("/home/vitor/Documentos/workspace/projeto_poo/Utilizadores/Dados/" + s);
		
		if(arquivo.exists())
			throw new UtilizadorExistenteException("Utilizador existente!");
	}
	
}
	