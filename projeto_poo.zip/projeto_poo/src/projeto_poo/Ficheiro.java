package projeto_poo;

import java.io.File;
import java.util.ArrayList;

public class Ficheiro {
	
	public void existe(String s)
		throws UtilizadorExistenteException{
		File arquivo = new File("/home/paulo/workspace/projeto_poo/Utilizadores/Dados/" + s);
		
		if(arquivo.exists())
			throw new UtilizadorExistenteException("Utilizador existente!");
	}
	
}
	