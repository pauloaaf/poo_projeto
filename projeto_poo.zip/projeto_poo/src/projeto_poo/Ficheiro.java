package projeto_poo;

import java.io.BufferedReader;

/**
 * Funções relacionadas com ficheiros
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Ficheiro {
	/**
	 * 
	 * @param email, para ver se já existe um ficheiro com o mesmo email
	 * @throws UtilizadorExistenteException
	 */
	public void existe(String s)
		throws UtilizadorExistenteException{//Exceptions.java
		File arquivo = new File("/home/vitor/Documentos/workspace/projeto_poo/Utilizadores/Dados/" + s);
		
		if(arquivo.exists())
			throw new UtilizadorExistenteException("Utilizador existente!");//Exceptions.java
	}
	
	/**
	 * 
	 * @param email
	 * @param password
	 * @throws SemAutorizacaoException
	 * Funçao para ir buscar a password de um determinado email
	 */
	public void pass(String email,String password)	
			throws SemAutorizacaoException{//Exceptions.java
		File arquivo = new File("/home/paulo/workspace/projeto_poo/Utilizadores/Dados/"+email);
		FileReader fr=null;
		try {fr = new FileReader( arquivo ); 
		} 
		catch(FileNotFoundException exc){ throw new SemAutorizacaoException("Utilizador nao registado!"); }
		BufferedReader br = new BufferedReader( fr ); 
		int i=0;
		String linha="";
		while(i<3){
			
		 try {linha = br.readLine();} 
		 catch(IOException exc){ exc.toString();}
		 i++;
		} 
		try{br.close();
		fr.close();} 
		catch(IOException exc){exc.toString();}
	   
		if(!password.equals(linha)) 
			throw new SemAutorizacaoException("Password errada!");//Exceptions.java
		}
	
}
	