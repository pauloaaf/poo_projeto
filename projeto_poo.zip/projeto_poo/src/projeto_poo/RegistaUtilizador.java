package projeto_poo;

/**
 * Class para tratar do registo do utilizador
 */

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class RegistaUtilizador {
	
	/**
	 * 
	 * @param utilizador
	 * @return bool caso o utilizador seja registado
	 * @throws UtilizadorExistenteException
	 */
	public boolean registar(Utilizador utilizador)
		throws UtilizadorExistenteException{
		
		Ficheiro novo = new Ficheiro();
		try{ // verificar se o utilizador existe
			novo.existe(utilizador.getEmail());
		}catch(UtilizadorExistenteException exc){
			throw new UtilizadorExistenteException("Utilizador existente!");
		}
		
		FileWriter ficheiro = null;
		try{ //verificar se o ficheiro abre corretamente
			ficheiro = new FileWriter("/home/vitor/Documentos/workspace/projeto_poo/Utilizadores/Dados/" + utilizador.getEmail());
		}catch(IOException exc){
			throw new UtilizadorExistenteException("Erro!");
		}
		BufferedWriter criar = new BufferedWriter(ficheiro);
		try{ //verificar se a escrita é feita corretamente
			criar.write(utilizador.getEmail());
			criar.newLine();
			criar.write(utilizador.getNome());
			criar.newLine();
			criar.write(utilizador.getPassword());
			criar.newLine();
			criar.write(utilizador.getMorada());
			criar.newLine();
			criar.write(Integer.toString(utilizador.getTipo()));
			criar.newLine();
			criar.close();
			ficheiro.close();
		}catch(IOException exc){
			throw new UtilizadorExistenteException("Erro!");
		}
		return true;
	}
	
	/**
	 * Esta funçao recolhe os vários dados associados a um utilizador
	 * @return utilizador com os dados colocados nas variáveis
	 */

	public Utilizador recolheDados(){
		String email, nome, password, data, morada;
		int tipo;
		Scanner s = new Scanner (System.in);
		System.out.print("\nEmail: ");
		email = s.nextLine();
		System.out.print("\nNome: ");
		nome = s.nextLine();
		System.out.print("\nPassword: ");
		password = s.nextLine();
		System.out.print("\nData de nascimento: ");
		data = s.nextLine();
		System.out.print("\nMorada: ");
		morada = s.nextLine();
		System.out.print("\nTipo de Utilizador: ");
		tipo = s.nextInt();
		s.close();
		return new Utilizador(email,nome,password,data,morada,tipo);
	}
}
