package projeto_poo;

import java.util.Scanner;

public class RegistaUtilizador {

	public Utilizador recolheDados(){
		Scanner s = new Scanner (System.in);
		System.out.println("Email: ");
		s.hasNext()
		Utilizador utilizador = new U
	}
}
