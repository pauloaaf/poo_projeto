package projeto_poo;

import java.io.File;
import java.util.ArrayList;

public class ImoveisRegistados {
	ArrayList<Imovel> imoveis;
	
	public ImoveisRegistados() {
		imoveis = new ArrayList<Imovel>();
	}
	
	
}
