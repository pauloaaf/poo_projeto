package projeto_poo;

public class Imovel{

	private String rua;
    private double precoPedido;
    private double precoMinimo;
    private String tipoImovel; //moradia, apartamento, loja, terreno
    
	public String getRua() {
		return rua;
	}
	public void setRua(String rua) {
		this.rua = rua;
	}
	public double getPrecoPedido() {
		return precoPedido;
	}
	public void setPrecoPedido(double precoPedido) {
		this.precoPedido = precoPedido;
	}
	public double getPrecoMinimo() {
		return precoMinimo;
	}
	public void setPrecoMinimo(double precoMinimo) {
		this.precoMinimo = precoMinimo;
	}
	public String getTipoImovel() {
		return tipoImovel;
	}
	public void setTipoImovel(String tipoImovel) {
		this.tipoImovel = tipoImovel;
	}
	public Imovel(String rua, double precoPedido, double precoMinimo, String tipoImovel){
		this.rua = rua;
		this.precoPedido = precoPedido;
		this.precoMinimo = precoMinimo;
		this.tipoImovel = tipoImovel;
	}
	public Imovel(Imovel im){
		this(im.getRua(), im.getPrecoPedido(), im.getPrecoMinimo(), im.getTipoImovel());
	}
	
	public String toString(){
		return rua+", "+precoPedido+", "+precoMinimo+", "+tipoImovel;
	}
	
	public boolean equals(Object o){
		if(o == this) return true;
		if(o.getClass()!= this.getClass()) return false;
		Imovel im = (Imovel) o;
		return im.getRua() == this.getRua() && im.getPrecoMinimo() == this.getPrecoMinimo() && im.getPrecoPedido() == this.getPrecoPedido()
				&& im.getTipoImovel() == this.getTipoImovel();
	}
	
	public Imovel clone(){
		return new Imovel(this);
	}
}

