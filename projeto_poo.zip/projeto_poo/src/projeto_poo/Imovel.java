package projeto_poo;

public class Imovel{

	private String rua;
    private double precoPedido;
    private double precoMinimo;
    private String tipoImovel; //moradia, apartamento, loja, terreno
    
	public String getRua() {
		return rua;
	}
	public void setRua(String rua) {
		this.rua = rua;
	}
	public double getPrecoPedido() {
		return precoPedido;
	}
	public void setPrecoPedido(double precoPedido) {
		this.precoPedido = precoPedido;
	}
	public double getPrecoMinimo() {
		return precoMinimo;
	}
	public void setPrecoMinimo(double precoMinimo) {
		this.precoMinimo = precoMinimo;
	}
	public String getTipoImovel() {
		return tipoImovel;
	}
	public void setTipoImovel(String tipoImovel) {
		this.tipoImovel = tipoImovel;
	}
	public Imovel(String rua, double precoPedido, double precoMinimo, String tipoImovel){
		this.rua = rua;
		this.precoPedido = precoPedido;
		this.precoMinimo = precoMinimo;
		this.tipoImovel = tipoImovel;
	}
	public Imovel(Imovel im){
		this(im.getRua(), im.getPrecoPedido(), im.getPrecoMinimo(), im.getTipoImovel());
	}
}


class Moradia extends Imovel{
	
    private String tipo;
    private double areaImplantacao;
    private double areaCoberta;
    private double areaEnvolvente;
    private int quartos;
    private int wc;
    private int porta;
    
    //get e sets de moradia 
    
    public String getTipo(){
    	return tipo;
    }
    
    public void setTipo(String tipo){
    	this.tipo = tipo;
    }

	public double getAreaImp() {
		return areaImplantacao;
	}

	public void setAreaImp(double areaImplantacao) {
		this.areaImplantacao = areaImplantacao;
	}

	public double getAreaCob() {
		return areaCoberta;
	}

	public void setAreaCob(double areaCoberta) {
		this.areaCoberta = areaCoberta;
	}

	public double getAreaEnv() {
		return areaEnvolvente;
	}

	public void setAreaEnv(double areaEnvolvente) {
		this.areaEnvolvente = areaEnvolvente;
	}

	public int getQuartos() {
		return quartos;
	}

	public void setQuartos(int quartos) {
		this.quartos = quartos;
	}

	public int getWc() {
		return wc;
	}

	public void setWc(int wc) {
		this.wc = wc;
	}

	public int getPorta() {
		return porta;
	}

	public void setPorta(int porta) {
		this.porta = porta;
	}

	
    //construtor moradia
    public Moradia(String rua, double precoPedido, double precoMinimo, String tipoImovel,String tipo, double areaImplantacao, double areaCoberta, double areaEnvolvente
    , int quartos, int wc, int porta) {
        super(rua,precoPedido,precoMinimo,tipoImovel);
        this.tipo = tipo;
        this.areaImplantacao = areaImplantacao;
        this.areaCoberta = areaCoberta;
        this.areaEnvolvente = areaEnvolvente;
        this.quartos = quartos;
        this.wc = wc;
        this.porta = porta;
    }
    
    public Moradia (Moradia m) {
        this(m.getRua(),m.getPrecoPedido(),m.getPrecoMinimo(),m.getTipoImovel(),m.getTipo(),m.getAreaImp(),
        		m.getAreaCob(),m.getAreaEnv(),m.getQuartos(),m.getWc(),m.getPorta());
    }

}
//class apartamento 

class Apartamento extends Imovel{
	
	private String tipo;
    private double areaTotal;
    private int quartos;
    private int wc;
    private int porta;
    private int andar;
    private boolean garagem;
    
    //get e set apartamento
    
    public String getTipo(){
    	return tipo;
    }
    
    public void setTipo(String tipo){
    	this.tipo = tipo;
    }
	public double getAreaTotal() {
		return areaTotal;
	}

	public void setAreaTotal(double areaTotal) {
		this.areaTotal = areaTotal;
	}

	public int getQuartos() {
		return quartos;
	}

	public void setQuartos(int quartos) {
		this.quartos = quartos;
	}

	public int getWc() {
		return wc;
	}

	public void setWc(int wc) {
		this.wc = wc;
	}

	public int getPorta() {
		return porta;
	}

	public void setPorta(int porta) {
		this.porta = porta;
	}

	public int getAndar() {
		return andar;
	}

	public void setAndar(int andar) {
		this.andar = andar;
	}

	public boolean getGaragem() {
		return garagem;
	}

	public void setGaragem(boolean garagem) {
		this.garagem = garagem;
	}

	//construtor apartamento
    public Apartamento(String rua, double precoPedido, double precoMinimo, String tipoImovel,String tipo, double areaTotal, int quartos, int wc, int porta
    		, int andar, boolean garagem) {
    	super(rua,precoPedido,precoMinimo,tipoImovel);
    	this.tipo = tipo;
    	this.areaTotal = areaTotal;
    	this.quartos = quartos;
    	this.wc = wc;
    	this.porta = porta;
    	this.andar = andar;
    	this.garagem = garagem;
    }
    
    public Apartamento(Apartamento a) {
    	this(a.getRua(),a.getPrecoPedido(),a.getPrecoMinimo(),a.getTipoImovel(),a.getTipo(),a.getAreaTotal(),a.getQuartos(),a.getWc(),a.getPorta()
    			,a.getAndar(),a.getGaragem());
    }    
   

}
//class loja 
class Loja extends Imovel{
	
    private double area;
    private boolean wc;
    private String tipoNegocio;
    private int porta;
    
    //get e set loja
    
	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	public boolean getWc() {
		return wc;
	}

	public void setWc(boolean wc) {
		this.wc = wc;
	}

	public String getTipoNegocio() {
		return tipoNegocio;
	}

	public void setTipoNegocio(String tipoNegocio) {
		this.tipoNegocio = tipoNegocio;
	}

	public int getPorta() {
		return porta;
	}

	public void setPorta(int porta) {
		this.porta = porta;
	}


    // Para parte habitacional - informa��o guardada para os apartamentos
	// construtor loja
    public Loja(String rua, double precoPedido, double precoMinimo,String tipoImovel, double area, boolean wc, String tipoNegocio, int porta) {
    	super(rua,precoPedido,precoMinimo,tipoImovel);
    	this.area = area;
    	this.wc = wc;
    	this.tipoNegocio = tipoNegocio;
    	this.porta = porta;
    }
    
    public Loja(Loja l) {
    	this(l.getRua(),l.getPrecoPedido(),l.getPrecoMinimo(),l.getTipoImovel(),l.getArea(),l.getWc(),l.getTipoNegocio(),l.getPorta());
    }
    
   
}
// class terreno
class Terreno extends Imovel{
	
    private double areaConstrucao;
    private boolean tipoConstrucao; // True para habita�ao e armazem, False apenas para armazem 
    private double diametro; // milimetros
    private double kwh; // kilowats da rede eletrica
    private boolean redeEletrica, redeEsgotos;
	
    //get e set terreno

	public double getAreaConstrucao() {
		return areaConstrucao;
	}

	public void setAreaConstrucao(double areaConstrucao) {
		this.areaConstrucao = areaConstrucao;
	}

	public boolean isTipoConstrucao() {
		return tipoConstrucao;
	}

	public void setTipoConstrucao(boolean tipoConstrucao) {
		this.tipoConstrucao = tipoConstrucao;
	}

	public double getDiametro() {
		return diametro;
	}

	public void setDiametro(double diametro) {
		this.diametro = diametro;
	}

	public double getKwh() {
		return kwh;
	}

	public void setKwh(double kwh) {
		this.kwh = kwh;
	}

	public boolean isRedeEletrica() {
		return redeEletrica;
	}

	public void setRedeEletrica(boolean redeEletrica) {
		this.redeEletrica = redeEletrica;
	}

	public boolean isRedeEsgotos() {
		return redeEsgotos;
	}

	public void setRedeEsgotos(boolean redeEsgotos) {
		this.redeEsgotos = redeEsgotos;
	}

    //construtor terreno
    public Terreno(String rua, double precoPedido, double precoMinimo,String tipoImovel, double areaConstrucao
    		, boolean tipoConstrucao, double diametro, double kwh, boolean redeEletrica, boolean redeEsgotos) {
    	super(rua,precoPedido,precoMinimo,tipoImovel);
    	this.areaConstrucao = areaConstrucao;
    	this.tipoConstrucao = tipoConstrucao;
    	this.diametro = diametro;
    	this.kwh = kwh;
    	this.redeEletrica = redeEletrica;
    	this.redeEsgotos = redeEsgotos;
    }
    
    public Terreno(Terreno t) {
    	this(t.getRua(),t.getPrecoPedido(),t.getPrecoMinimo(),t.getTipoImovel(),t.getAreaConstrucao(),t.isTipoConstrucao()
    			,t.getDiametro(),t.getKwh(),t.isRedeEletrica(),t.isRedeEsgotos());
    }
    
    
}

