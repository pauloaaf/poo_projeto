package projeto_poo;

/**
 * 
 * @author paulo
 * Classe para criar um vendedor ou um comprador
 *
 */

public class Utilizador {
	private String email; 
	private String nome;
	private String password;
	private String morada;
	private String data; //data de nascimento
	private int tipo; //define se o utilizador é um vendedor ou um comprador: 
							// 0 se for vendedor
							// 1 se for comprador

	
	public Utilizador(String email, String nome, String password, String data,String morada,int tipo) {
		this.email = email;
		this.nome = nome;
		this.password = password;
		this.data = data;
		this.morada = morada;
		this.tipo = tipo;
	}
	
	public Utilizador(Utilizador u){
		this(u.getEmail(),u.getNome(),u.getPassword(),u.getData(),u.getMorada(),u.getTipo());
	}
	
	public String getEmail(){return email;}
	public String getNome(){return nome;}
	public String getPassword(){return password;}
	public String getData(){return data;}
	public String getMorada(){return morada;}
	public int getTipo(){return tipo;}
	public void setEmail(String email){this.email = email;}
	public void setNome(String nome){this.nome = nome;}
	public void setPassword(String password){this.password = password;}
	public void setData(String data){this.data = data;}		
	public void setMorada(String morada){}
	public void setTipo(int tipo){this.tipo= tipo;}
	
	public Utilizador clone(){
		return new Utilizador(this);
	}
	
	public boolean equals(Object o){
		if(o == this) return true;
		if(o.getClass() != this.getClass()) return false;
		Utilizador n = (Utilizador) o;
		return n.getData() == this.getData() && n.getEmail() == this.getEmail() && n.getMorada() == this.getMorada()
			&& n.getNome() == this.getNome() && n.getPassword() == this.getPassword() && n.getTipo() == this.getTipo();
	}
}


