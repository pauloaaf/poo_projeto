package projeto_poo;

class  UtilizadorExistenteException extends Exception{ //Classe para tratar das exceçoes, quando o utilizador ja existe
	
	private String s;
	
	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}

	public UtilizadorExistenteException(String s){
		this.s = s;
	}

	public String toString(String s) {
		return s;
	}
}

public class Exceptions {

}
