package projeto_poo;

class UtilizadorExistenteException extends Exception{

	public String toString() {
		return "Utilizador existente!";
	}
}

public class Exceptions {

}
