package projeto_poo;

/**
 * 
 * Classe utilizada para verificar se um utilizador ja existe
 *
 */
class  UtilizadorExistenteException extends Exception{
	
	private String s;
	
	public String getS() {return s;}

	public void setS(String s) {this.s = s;}

	public UtilizadorExistenteException(String s){
		this.s = s;
	}

	public String toString() {
		return s;
	}
}

/**
 * 
 * Classe utilizada quando um utilizador nao tem permissao para realizar alguma tarefa
 *
 */
class SemAutorizacaoException extends Exception{
	private String s;

	public SemAutorizacaoException(String s) {
		this.s=s;
	} 
	
	public SemAutorizacaoException(){
		this("Sem Autorização!");
	}

	public String toString(){return s;}
}

public class Exceptions {

}
