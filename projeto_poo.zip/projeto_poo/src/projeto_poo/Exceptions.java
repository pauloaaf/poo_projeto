package projeto_poo;

class UtilizadorExistenteException extends Exception{
	private String s;
	
	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}

	public UtilizadorExistenteException(String s){
		this.s = s;
	}

	public String toString(String s) {
		return s;
	}
}

public class Exceptions {

}
