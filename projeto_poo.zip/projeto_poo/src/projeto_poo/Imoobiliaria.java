package projeto_poo;

import java.util.ArrayList;

public class Imoobiliaria {
	
	public static void registaUtilizador(Utilizador utilizador)
		throws UtilizadorExistenteException{
		Ficheiro novo = new Ficheiro();
		
		try{
			novo.existe(utilizador.getEmail());
		}catch(UtilizadorExistenteException exc){
			System.out.println(exc.toString());
		}
		
	}
	
	public static void initApp()
		throws UtilizadorExistenteException{
		Utilizador n = new Utilizador("alfredo","asa","*****","dsad","fsd",0);
		registaUtilizador(n);
	}

	public static void main(String[] args)
		throws UtilizadorExistenteException{
		initApp();
	}
}
