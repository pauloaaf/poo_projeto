package projeto_poo;


public class Imoobiliaria {
	
	public static void registaUtilizador(Utilizador utilizador)
		throws UtilizadorExistenteException{
		RegistaUtilizador r = new RegistaUtilizador();
		r.registar(utilizador);
	}
	
	public static void initApp(){
		RegistaUtilizador r = new RegistaUtilizador();
		Utilizador utilizador = r.recolheDados();
		try{
			registaUtilizador(utilizador);
		}catch(UtilizadorExistenteException exc){
			System.out.println(exc.toString("Utilizador existente!"));
		}
	}

	public static void main(String[] args)
		throws UtilizadorExistenteException{
		initApp();
	}
}
