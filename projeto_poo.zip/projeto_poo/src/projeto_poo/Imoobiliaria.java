package projeto_poo;


public class Imoobiliaria {
	private boolean sessaoIniciada = false;
	
	
	public boolean isSessaoInicia() {return sessaoIniciada;}

	public void setSessaoInicia(boolean sessaoIniciada) {this.sessaoIniciada = sessaoIniciada;}

	public static void registaUtilizador(Utilizador utilizador)
		throws UtilizadorExistenteException{
		RegistaUtilizador r = new RegistaUtilizador();
		r.registar(utilizador);
	}
	
	public static void iniciaSessao(String email, String password)
		throws SemAutorizacaoException{
		Ficheiro f = new Ficheiro();
		try{f.pass(email, password);}
		catch(SemAutorizacaoException exc){
			throw new SemAutorizacaoException(exc.toString());
		}
	}
	
	public static void initApp(){
		RegistaUtilizador r = new RegistaUtilizador();
		//Utilizador utilizador = r.recolheDados();
		try{
			iniciaSessao("alfredo", "alfr");
		}catch(SemAutorizacaoException exc){
			System.out.println(exc.toString());
		}
		
	}

	public static void main(String[] args)
		throws UtilizadorExistenteException{
		initApp();
	}
}
