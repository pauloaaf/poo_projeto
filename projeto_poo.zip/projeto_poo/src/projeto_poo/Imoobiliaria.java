package projeto_poo;


public class Imoobiliaria {
	private boolean sessaoIniciada = false;
	
	
	public boolean getSessaoInicia() {return sessaoIniciada;}

	public void setSessaoInicia(boolean sessaoIniciada) {this.sessaoIniciada = sessaoIniciada;}
	
	public void registaImovel(Imovel im)
		throws ImovelExisteException,
			   SemAutorizacaoException{
		
	}

	public void registaUtilizador(Utilizador utilizador)
		throws UtilizadorExistenteException{
		RegistaUtilizador r = new RegistaUtilizador();
		r.registar(utilizador);//RegistaUtilizador.java
	}
	
	public void iniciaSessao(String email, String password)
		throws SemAutorizacaoException{//Exceptions.java
		Ficheiro f = new Ficheiro();
		try{f.pass(email, password);}//Ficheiro.java
		catch(SemAutorizacaoException exc){//Exceptions.java
			throw new SemAutorizacaoException(exc.toString());//Exceptions.java
		}
		sessaoIniciada = true;
	}
	
	public static void initApp(){
		RegistaUtilizador r = new RegistaUtilizador();//RegistaUtilizador.java
		//Utilizador utilizador = r.recolheDados();
		
		
	}

	public static void main(String[] args)
		throws UtilizadorExistenteException{
		//initApp();
		Ficheiro f = new Ficheiro();
		f.carregaImoveis();
	}
}
