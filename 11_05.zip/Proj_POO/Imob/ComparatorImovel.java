package Imob;

 


/**
 * Write a description of class ComparatorImovel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.Comparator;

public class ComparatorImovel implements Comparator<Imovel>{
    
    public int compare(Imovel im1, Imovel im2){
        return im1.compareTo(im2);
    }
}
