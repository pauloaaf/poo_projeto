package Imob;



/**
 * Enumeration class TipoMoradia - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum TipoMoradia{
    Isolada, Geminada,Banda, Gaveto, Indefinido;
}
