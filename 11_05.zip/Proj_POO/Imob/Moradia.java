package Imob;

 

 

class Moradia extends Imovel implements Habitavel{
    
    private TipoMoradia tipo;
    private double areaImplantacao;
    private double areaCoberta;
    private double areaEnvolvente;
    private int quartos;
    private int wc;
    private int porta;
    
    //construtor moradia
    public Moradia(String rua, double precoPedido, double precoMinimo, EstadoImovel estado, TipoMoradia tipo, double areaImplantacao, double areaCoberta, double areaEnvolvente
    , int quartos, int wc, int porta) {
        super(rua,precoPedido,precoMinimo,estado);
        this.tipo = tipo;
        this.areaImplantacao = areaImplantacao;
        this.areaCoberta = areaCoberta;
        this.areaEnvolvente = areaEnvolvente;
        this.quartos = quartos;
        this.wc = wc;
        this.porta = porta;
        geraIdentificador();
    }
    
    public Moradia (Moradia m) {
        this(m.getRua(),m.getPrecoPedido(),m.getPrecoMinimo(), m.getEstado(), m.getTipo(),m.getAreaImp(),
                m.getAreaCob(),m.getAreaEnv(),m.getQuartos(),m.getWc(),m.getPorta());
    }
    
    public Moradia(){
        this("N/A",0.0,0.0,EstadoImovel.Indefinido,TipoMoradia.Indefinido,0.0,0.0,0.0,-1,-1,-1);        
    }
    
    //get e sets de moradia 
    
    public TipoMoradia getTipo(){
        return tipo;
    }
    
    public void setTipo(TipoMoradia tipo){
        this.tipo = tipo;
    }

    public double getAreaImp() {
        return areaImplantacao;
    }

    public void setAreaImp(double areaImplantacao) {
        this.areaImplantacao = areaImplantacao;
    }

    public double getAreaCob() {
        return areaCoberta;
    }

    public void setAreaCob(double areaCoberta) {
        this.areaCoberta = areaCoberta;
    }

    public double getAreaEnv() {
        return areaEnvolvente;
    }

    public void setAreaEnv(double areaEnvolvente) {
        this.areaEnvolvente = areaEnvolvente;
    }

    public int getQuartos() {
        return quartos;
    }

    public void setQuartos(int quartos) {
        this.quartos = quartos;
    }

    public int getWc() {
        return wc;
    }

    public void setWc(int wc) {
        this.wc = wc;
    }

    public int getPorta() {
        return porta;
    }

    public void setPorta(int porta) {
        this.porta = porta;
    }

    
    public Moradia clone(){
        return new Moradia (this);
    }

    public boolean equals(Object o){
        if(o == this) return true;
        if(o == null || o.getClass()!= this.getClass()) return false;
        Moradia m = (Moradia) o;
        
        return super.equals(o);
    }
    
    public String toString(){
        StringBuilder str = new StringBuilder();
        
        str.append(super.toString()+ ", ");
        str.append(tipo + ", ");
        str.append(Double.toString(areaImplantacao)+ ", ");
        str.append(Double.toString(areaCoberta)+ ", ");
        str.append(Double.toString(areaEnvolvente)+ ", ");
        str.append(Integer.toString(quartos)+ ", ");
        str.append(Integer.toString(wc)+ ", ");
        str.append(Integer.toString(porta));
        
        return str.toString();
    }
    
    public void geraIdentificador(){
        int id = super.identificadorImovel();
        
        //Id para Classe
        
        id+=this.getClass().getSimpleName().hashCode();
        
        //Id tipo
        id+=tipo.hashCode();
        
        //Id areaImplantacao
        int p = (int) Double.doubleToLongBits(areaImplantacao);
        id+=(p^(p>>>32));
        
        //id areaCoberta
        p = (int) Double.doubleToLongBits(areaCoberta);
        id+=(p^(p>>>32));
        
        //Id areaEnvolvente
        
        p = (int) Double.doubleToLongBits(areaEnvolvente);
        id+=(p^(p>>>32));
        
        //Id quartos, wc, porta
        
        id+= quartos+porta+wc;
        
        super.setIdentificador(id + "");
    }
    
}