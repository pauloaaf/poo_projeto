package Imob;




/**
 * Write a description of class EstadoInvalidoExcpetion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EstadoInvalidoException extends Exception{
    private String s;
	
	public EstadoInvalidoException(String s){
		this.s = s;
	}
	
	public String toString(){
		return s;
	}
}
