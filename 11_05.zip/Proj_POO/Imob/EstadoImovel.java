package Imob;




/**
 * Enumeration class EstadoImovel - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum EstadoImovel{
    Venda, Reservado, Vendido, Arrendamento, Trespasse, Indefinido;
}
