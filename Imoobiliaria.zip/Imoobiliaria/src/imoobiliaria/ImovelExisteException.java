package imoobiliaria; 

public class ImovelExisteException extends Exception{
	private String s;
	
	public ImovelExisteException(String s){
		this.s = s;
	}
	
	public String toString(){
		return s;
	}
}
