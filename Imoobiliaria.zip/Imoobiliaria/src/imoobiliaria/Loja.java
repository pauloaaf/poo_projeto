package imoobiliaria; 

public class Loja extends Imovel{
	
    private double area;
    private boolean wc;
    private String tipoNegocio;
    private int porta;
    
    //Construtor Loja
    
    public Loja(){
		super();
		this.area = 0;
		this.wc = false;
		this.tipoNegocio = "N/A";
		this.porta =0;
		geraIdentificador();
		
	}
	
	 // Para parte habitacional - informa��o guardada para os apartamentos
	// construtor loja
    public Loja(String rua, double precoPedido, double precoMinimo, EstadoImovel estado, double area, boolean wc, String tipoNegocio, int porta) {
    	super(rua,precoPedido,precoMinimo,estado);
    	this.area = area;
    	this.wc = wc;
    	this.tipoNegocio = tipoNegocio;
    	this.porta = porta;
    	geraIdentificador();
    }
    
    public Loja(Loja l) {
    	this(l.getRua(),l.getPrecoPedido(),l.getPrecoMinimo(), l.getEstado(), l.getArea(),l.getWc(),l.getTipoNegocio(),l.getPorta());
    }
    
    //get e set loja
    
	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	public boolean getWc() {
		return wc;
	}

	public void setWc(boolean wc) {
		this.wc = wc;
	}

	public String getTipoNegocio() {
		return tipoNegocio;
	}

	public void setTipoNegocio(String tipoNegocio) {
		this.tipoNegocio = tipoNegocio;
	}

	public int getPorta() {
		return porta;
	}

	public void setPorta(int porta) {
		this.porta = porta;
	}

    
    public Loja clone(){
    	return new Loja(this);
    }
    
    public boolean equals(Object o){
    	if(o == this) return true;
		if(o == null || o.getClass()!= this.getClass()) return false;
		Loja loja = (Loja) o;
		
		return super.equals(o);
    }
    
    public String toString(){
    	StringBuilder str = new StringBuilder();
    	
    	str.append(super.toString() + ", ");
    	str.append(Double.toString(area) + ", ");
    	str.append(String.valueOf(wc) +", ");
    	str.append(tipoNegocio + ", ");
    	str.append(Integer.toString(porta));
    	
    	return str.toString();
    	
    }
   
    public void geraIdentificador(){
        int id = super.identificadorImovel();
        
        //Id para Classe
        
        id+=this.getClass().getSimpleName().hashCode();
        
        //Id area
        int p = (int) Double.doubleToLongBits(area);
        id+= (p^(p>>>32));
        
        //Id wc
        id+= (wc ? 0:1);
        
        //id tipoNegocio
        id+=tipoNegocio.hashCode();
        
        //Id porta
        
        id+=porta;
        
        super.setIdentificador(id + "");
    }
    
}




