package imoobiliaria;
/**
 * Write a description of class ImovelInexistenteException here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ImovelInexistenteException extends Exception{
    private String s;
    
    public ImovelInexistenteException(String s){
        this.s = s;
    }
    
    public String toString(){
        return s;
    }
}
