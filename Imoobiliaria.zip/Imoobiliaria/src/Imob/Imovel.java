package Imob;
import java.util.Comparator;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class Imovel implements Comparable<Imovel>, Serializable{

    private String rua;
    private double precoPedido;
    private double precoMinimo;
    private String identificador;
    private EstadoImovel estado;
    private String emailVendedor;
    private static final long serialVersionUID = 1L;
    private List<Consulta> consultas;
    
    //Construtores
    public Imovel(String rua, double precoPedido, double precoMinimo,EstadoImovel estado,String email){
        this.rua = rua;
        this.precoPedido = precoPedido;
        this.precoMinimo = precoMinimo;
        this.estado = estado;
        emailVendedor = email;
        consultas = new ArrayList<>();
    }
    
    public Imovel(Imovel im){
        this(im.getRua(), im.getPrecoPedido(), im.getPrecoMinimo(),im.getEstado(),im.getEmailVendedor());
        consultas = im.getConsultas();
    }
    
    public Imovel(){
        this("N/A",0.0,0.0,EstadoImovel.Indefinido,"N/A");
        consultas = new ArrayList<>();
    }
    
    //Gets e Sets
    
    public String getEmailVendedor(){
        return emailVendedor;
    }
    public void setEmailVendedor(String email){
        emailVendedor = email;
    }
    public List<Consulta> getConsultas(){
        List<Consulta> res = new ArrayList<>();
        for(Consulta c:consultas)
            res.add(c.clone());
        return res;
    }
    
    public void setConsultas(List<Consulta> c){
        consultas.clear();
        for(Consulta con:c){
            consultas.add(con.clone());
        }
    }

    public String getRua() {
        return rua;
    }
    public void setRua(String rua) {
        this.rua = rua;
    }
    public double getPrecoPedido() {
        return precoPedido;
    }
    public void setPrecoPedido(double precoPedido) {
        this.precoPedido = precoPedido;
    }
    public double getPrecoMinimo() {
        return precoMinimo;
    }
    public void setPrecoMinimo(double precoMinimo) {
        this.precoMinimo = precoMinimo;
    }
    
    public String getIdentificador(){
        return identificador;
    }
    
    public void setIdentificador(String identificador){
        this.identificador = identificador;
    }
    
    public EstadoImovel getEstado(){
        return estado;
    }
    
    public void setEstado(EstadoImovel estado){
        this.estado = estado;
    }
    
    public String toString(){
        return rua+", "+precoPedido+", "+precoMinimo+ ", " + identificador + ", " + estado;
    }
    
    public void acrescentaConsulta(Consulta c){
        consultas.add(c.clone());
    }
    
    public Imovel clone(){
        return new Imovel(this);
    }
    
    public boolean equals(Object o){
        if(o == this) return true;
        if(o == null || o.getClass()!= this.getClass()) return false;
        Imovel im = (Imovel) o;
        return identificador.equals(im.getIdentificador()) && rua.equals(im.getRua()) && precoPedido == im.getPrecoPedido()
            && precoMinimo == im.getPrecoMinimo() && String.valueOf(estado).equals(String.valueOf(im.getEstado()))
            && emailVendedor.equals(emailVendedor);
    }
    
    public int compareTo(Imovel im){
        
        if(this.getPrecoMinimo()<im.getPrecoMinimo())
            return -1;
        if(this.getPrecoMinimo()<im.getPrecoMinimo())
            return 1;
        return 0;
    }
    
}

