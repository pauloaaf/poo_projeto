package Imob;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Set;
import java.util.TreeSet;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.Comparator;
import java.util.Iterator;

public class Imoobiliaria implements Serializable{
    private static final long serialVersionUID = 1L;
    private boolean sessaoIniciada = false;
    private Utilizador utilizadorIniciado = null;
    private Map<String,Utilizador> utilizadoresRegistados; // map com email como chave e utilizador como valor
    private Map<String,Imovel> imoveisRegistados; //map com idImovel como chave e imovel como valor
    private List<Consulta> consultas; //String -> idImovel, Consulta
    
    public Imoobiliaria(){
        utilizadoresRegistados = new TreeMap<>();
        imoveisRegistados = new TreeMap<>();
        consultas = new ArrayList<>();
    }
    
    public Imoobiliaria(Imoobiliaria im){
        sessaoIniciada = im.getSessaoIniciada();
        utilizadorIniciado = im.getUtilizadorIniciado().clone();
        utilizadoresRegistados = im.getUtilizadoresRegistados();
        imoveisRegistados = im.getImoveisRegistados();
        consultas = im.getConsulta();
    }
    
    /*gets e sets*/
    public Utilizador getUtilizadorIniciado(){
        return utilizadorIniciado;
    }
    
    public List<Consulta> getConsulta(){
        List<Consulta> res = new ArrayList<>();
        for(Consulta c:consultas)
            res.add(c.clone());
        return res;
    }
    
    public void setConsultas(List<Consulta> c){
        consultas.clear();
        for(Consulta cons:c)
            consultas.add(cons.clone());
    }
    
    
    
    public Map<String,Utilizador> getUtilizadoresRegistados(){
        Map<String,Utilizador> res = new TreeMap<>();
        for(Map.Entry<String,Utilizador> u:utilizadoresRegistados.entrySet())
            res.put(u.getValue().getEmail(),u.getValue().clone());
        return res;
    }
    
    public void setUtilizadoresRegistados(Map<String,Utilizador> utilizadores){
        utilizadoresRegistados.clear();
        for(Map.Entry<String,Utilizador> u:utilizadores.entrySet())
            utilizadoresRegistados.put(u.getKey(),u.getValue().clone());
        try{
            Guardar.gravaImoobiliaria(this);
        }catch(IOException exc){
            System.out.println("IOException!");
        }
    }
    
    public Map<String,Imovel> getImoveisRegistados(){
        Map<String,Imovel> res = new TreeMap<>();
        for(Map.Entry<String,Imovel> im:imoveisRegistados.entrySet()){
            res.put(im.getKey(),im.getValue().clone());
        }
            
        return res;
    }
    
    public void setImoveisRegistados(Map<String,Imovel> imoveisRegistados){
        this.imoveisRegistados.clear();
        for(Map.Entry<String,Imovel> im:imoveisRegistados.entrySet())
            this.imoveisRegistados.put(im.getKey(),im.getValue().clone());
        try{
            Guardar.gravaImoobiliaria(this);
        }catch(IOException exc){
            System.out.println("IOException!");
        }
    }
   
    
    public boolean getSessaoIniciada() {return sessaoIniciada;}

    public void setSessaoIniciada(boolean sessaoIniciada) {this.sessaoIniciada = sessaoIniciada;}
    
    /*Funçoes pdf*/
    public void registaImovel(Imovel im)
        throws ImovelExisteException,
               SemAutorizacaoException{
                     
        if(utilizadorIniciado == null)
            throw new SemAutorizacaoException("Necessário iniciar sessão!");
        if(utilizadorIniciado.getClass().getSimpleName().equals("Comprador"))
            throw new SemAutorizacaoException("Sem direitos");  
        
        if(imoveisRegistados.containsKey(im.getIdentificador()))
            throw new ImovelExisteException("Imovel ja registado!");
        else{
            imoveisRegistados.put(im.getIdentificador(),im);
            Vendedor v = (Vendedor) utilizadorIniciado;
            v.registaVender(im);
            
        }
        try{
            Guardar.gravaImoobiliaria(this);
        }catch(IOException exc){
            System.out.println("IOException!");
        }
                   
    }

    public void registarUtilizador(Utilizador utilizador)
        throws UtilizadorExistenteException{
        /*RegistaUtilizador r = new RegistaUtilizador();
        r.registar(utilizador);//RegistaUtilizador.java*/
        
        //verificar se o utilizador ja existe
        if(utilizadoresRegistados.containsKey(utilizador.getEmail()))
            throw new UtilizadorExistenteException("Email em uso!");
        else
            utilizadoresRegistados.put(utilizador.getEmail(),utilizador); 
        try{
            Guardar.gravaImoobiliaria(this);
        }catch(IOException exc){
            System.out.println("IOException!");
        }
    }
    
    public void iniciaSessao(String email, String password)
        throws SemAutorizacaoException{//Exceptions.java
        //Ficheiro f = new Ficheiro();
        
        if(!utilizadoresRegistados.containsKey(email))
            throw new SemAutorizacaoException("Utilizador nao existe!");
        
        if(utilizadoresRegistados.containsKey(email) && !utilizadoresRegistados.get(email).getPassword().equals(password))
                throw new SemAutorizacaoException("Password errada!");
        
        sessaoIniciada = true;
        utilizadorIniciado = utilizadoresRegistados.get(email);
        try{
            Guardar.gravaImoobiliaria(this);
        }catch(IOException exc){
            System.out.println("IOException!");
        }
    }
    
    public void fechaSessao(){
        sessaoIniciada = false;
        utilizadorIniciado = null;
        try{
            Guardar.gravaImoobiliaria(this);
        }catch(IOException exc){
            System.out.println("IOException!");
        }
        
    }
    
    public List<Consulta > getConsultas ()
        throws SemAutorizacaoException{
        if(!(utilizadorIniciado instanceof Vendedor))
            throw new SemAutorizacaoException("Precisa de ser um vendedor!");

        Vendedor v = (Vendedor) utilizadorIniciado;
        List<Consulta> lista = new ArrayList<>();
        Iterator<Consulta> it = consultas.iterator();
        int i = 0;
        while(it.hasNext() && i<10){
            Consulta c = it.next();
            Imovel im = imoveisRegistados.get(c.getIdImovel());
            if(v.getVender().contains(im)){
                lista.add(c);
                i++;
            }
        }
        return lista;  
    }
    
    public Set<String> getTopImoveis(int n)
        throws SemAutorizacaoException{
        if(!(utilizadorIniciado instanceof Vendedor))
            throw new SemAutorizacaoException("Precisa de ser um vendedor!");
        
        Vendedor v = (Vendedor) utilizadorIniciado;
        Set<String> s = new TreeSet<>();
        for(Imovel i:v.getVender())
            if(consultasImovel(i).size()>=n)
                s.add(i.getIdentificador());
        
        return s;
    }
        
    public void setEstado (String idImovel, String estado)
        throws ImovelInexistenteException,
               SemAutorizacaoException,
               EstadoInvalidoException{
        
        if(utilizadorIniciado == null)
            throw new SemAutorizacaoException("Necessario iniciar sessao!");
        if(utilizadorIniciado.getClass().getSimpleName().equals("Comprador"))
            throw new SemAutorizacaoException("Sem direitos"); 
        
        if(!estado.equals("Venda") && !estado.equals("Reservado") && !estado.equals("Vendido") && !estado.equals("Arrendamento") && !estado.equals("Trespasse"))
            throw new EstadoInvalidoException("Estado invalido!");
        
        if(!imoveisRegistados.containsKey(idImovel))
            throw new ImovelInexistenteException("Imovel inexistente!");
        
        Imovel im = imoveisRegistados.get(idImovel);
                
        im.setEstado(EstadoImovel.valueOf(estado));
        Vendedor v = (Vendedor) utilizadorIniciado;
        if(estado.equals("Vendido")){
            v.getVender().remove(im);
            v.getVendidos().add(im);
        }
   
        try{
            Guardar.gravaImoobiliaria(this);
        }catch(IOException exc){
            System.out.println("IOException!");
        }
    }
    
    public Map<Imovel,Vendedor> getMapeamentoImoveis(){
        Map<Imovel,Vendedor> res = new TreeMap<>();
        for(Imovel im:imoveisRegistados.values())
            res.put(im, (Vendedor) utilizadoresRegistados.get(im.getEmailVendedor()));
        return res;
    }
    
    public List<Imovel> getImovel(String classe, int preco){
        List<Imovel> res = new ArrayList<>();
        for(Imovel im:imoveisRegistados.values()){
            if(im.getClass().getSimpleName().equals(classe) && im.getPrecoPedido()<=preco)
                res.add(im.clone());
        }
        return res;
    }
    
    
    /*Lista de todos os imoveis habitaveis, ate um certo preço*/
    public List<Habitavel> getHabitaveis(int preco){
        List<Habitavel> res = new ArrayList<>();
        
        for(Imovel im:imoveisRegistados.values()){
            if(im instanceof Habitavel && im.getPrecoPedido() <= preco){
                res.add((Habitavel) im.clone());
            }
        }
        return res;
    }
    
    /**
     * Compradores registados
     */
    
    public void setFavorito(String idImovel)
        throws ImovelInexistenteException,
               SemAutorizacaoException{
                
        if(!sessaoIniciada)
            throw new SemAutorizacaoException("E necessario iniciar sessao!");
        if(utilizadorIniciado instanceof Vendedor)
            throw new SemAutorizacaoException("Precisa de ser um comprador para realizar esta acao!");
        if(!imoveisRegistados.containsKey(idImovel))
            throw new ImovelInexistenteException("Imovel inexistente!");
        
        Comprador c = (Comprador) utilizadorIniciado;
        try{
            c.favorito(imoveisRegistados.get(idImovel));
        }catch(ImovelFavoritoException exc){
            throw new SemAutorizacaoException(exc.toString());
        }
        
        try{
            Guardar.gravaImoobiliaria(this);
        }catch(IOException exc){
            System.out.println("IOException!");
        }
    }
    /*Favoritos por ordem de preço*/
    public TreeSet<Imovel> getFavoritos ()
            throws SemAutorizacaoException {
        TreeSet<Imovel> fav = new TreeSet<>();
        if(!sessaoIniciada) {
            throw new SemAutorizacaoException("E necessario iniciar sessao!");
        }
        if(utilizadorIniciado instanceof Vendedor) {
            throw new SemAutorizacaoException("Precisa de ser um comprador para realizar esta acao!");
        }
        Comprador c = (Comprador) utilizadorIniciado;
        for(Imovel im : c.getFavorito().values()) {
            fav.add(im.clone());
        }
        return fav;
        
    }
    
    
    
    /**
     * Funçao para criar a pasta
     */
    
    public static void criaPasta(String nome){
        File pasta = new File("/home/paulo/"+nome);
        //Criar a pasta se ela não existir;
        if (!pasta.exists()) {
            try{
                pasta.mkdir();
            } 
            catch(SecurityException se){
                System.out.println("Erro ao criar a pasta!");
            }        
        }
    }
    
    /**
     * Funçao para gravar classe Imobiliaria
     */
    
    
    public void carregarDados(Imoobiliaria im){
        this.sessaoIniciada = false;
        this.utilizadorIniciado = null;
        this.setImoveisRegistados(im.getImoveisRegistados());
        this.setUtilizadoresRegistados(im.getUtilizadoresRegistados());
        this.setConsultas(im.getConsulta());
    }
    
    public static Imoobiliaria initApp(){
        Imoobiliaria im = new Imoobiliaria();
        im.carregarDados(Guardar.leImoobiliaria());       
        
        return im;
    }
    
    
    public Imoobiliaria clone(){
        return new Imoobiliaria(this);
    }
    
    /**
     * Extra
     */
    /**
     * Procura por classe
     */
    public List<Imovel> procura(String classe){
        List<Imovel> res = new ArrayList<>();
        for(Imovel im:imoveisRegistados.values())
            if(im.getClass().getSimpleName().equals(classe))
                res.add(im);
        return res;
    }
    
    /**
     * Ordenar imoveis
     */
    
    public TreeSet<Imovel> ordenar(ComparatorImovelPreco c){
        TreeSet<Imovel> res = new TreeSet<>(c);
        for(Imovel im:imoveisRegistados.values())
            res.add(im);
        return res;
    }
    
    /**
     * Acrescentar nova consulta
     */
    
    public void adicionaConsulta(Consulta c){
        consultas.add(0, c);
        try{
            Guardar.gravaImoobiliaria(this);
        }catch(IOException exc){
            System.out.println("IOException!");
        }
    }
    
    /**
     * Todas as consultas de um Imovel
     */
    
    public Set<Consulta> consultasImovel(Imovel im){
        Set<Consulta> res = new TreeSet<>();
        
        for(Consulta c:consultas)
            if(im.getIdentificador().equals(c.getIdImovel()))
                res.add(c.clone());
        return res;
                
    }
    
    /**
     * Id imovel associado ao Imovel num map
     */
    
    public String devolveKey(Map<String,Imovel> m,Imovel im){
        String s = null;
        for(Map.Entry<String,Imovel> conj:m.entrySet()){
            if(conj.getValue().equals(im)){
                s = conj.getKey();
                return s;
            }
        }
        return s;
    }
    
    
    /**
     * Limpar
     */
    
    public void limpa(){
        Imoobiliaria im = new Imoobiliaria();
        try{
            Guardar.gravaImoobiliaria(im);
        }catch(Exception exc){
            exc.printStackTrace();
        }
        
    }
}

