package Imob;
/**
 * Write a description of class LojaHabitavel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LojaHabitavel extends Imovel implements Habitavel{
    private String tipo;
    private double areaTotal;
    private int quartos;
    private int wc;
    private int andar;
    private boolean garagem;
    private double area;
    private boolean temWc;
    private String tipoNegocio;
    private int porta;

    //construtor apartamento

    public LojaHabitavel (){
        super();
        this.tipo = "N/A";
        this.areaTotal = 0;
        this.andar = 0;
        this.wc = 0;
        this.quartos = 0;
        this.porta = 0;
        this.garagem = false;
        this.temWc = false;
        this.tipoNegocio = "N/A";
        this.area = 0;
        geraIdentificador();
    }

    public LojaHabitavel(String rua, double precoPedido, double precoMinimo, EstadoImovel estado,String email, double area, boolean temWc, String tipoNegocio, int porta
                         ,String tipo, double areaTotal, int quartos, int qWc, int andar, boolean garagem) {
        super(rua,precoPedido,precoMinimo,estado,email);
        this.area = area;
        this.tipoNegocio = tipoNegocio;
        this.temWc = temWc;
        this.tipo = tipo;
        this.areaTotal = areaTotal;
        this.quartos = quartos;
        this.wc = qWc;
        this.porta = porta;
        this.andar = andar;
        this.garagem = garagem;
        geraIdentificador();
    }

    public LojaHabitavel(LojaHabitavel a) {
        this(a.getRua(),a.getPrecoPedido(),a.getPrecoMinimo(),a.getEstado(),a.getEmailVendedor(),a.getArea(), a.getTemWc(),a.getTipoNegocio(), a.getPorta()
                ,a.getTipo(),a.getAreaTotal(),a.getQuartos(),a.getQuantosWC(),a.getAndar(),a.getGaragem());
    }

    //get e set apartamento
    public double getArea() {
	return area;
    }

    public void setArea(double area) {
	this.area = area;
    }

    public boolean getTemWc() {
        return temWc;
    }

    public void seTemWc(boolean temWc) {
        this.temWc = temWc;
    }

    public String getTipoNegocio() {
        return tipoNegocio;
    }
    
    public void setTipoNegocio(String tipoNegocio) {
        this.tipoNegocio = tipoNegocio;
    }
    public String getTipo(){
        return tipo;
    }

    public void setTipo(String tipo){
        this.tipo = tipo;
    }
    public double getAreaTotal() {
        return areaTotal;
    }

    public void setAreaTotal(double areaTotal) {
        this.areaTotal = areaTotal;
    }

    public int getQuartos() {
        return quartos;
    }

    public void setQuartos(int quartos) {
        this.quartos = quartos;
    }

    public int getQuantosWC() {
        return wc;
    }

    public void setQuantosWC(int wc) {
        this.wc = wc;
    }

    public int getPorta() {
        return porta;
    }

    public void setPorta(int porta) {
        this.porta = porta;
    }

    public int getAndar() {
        return andar;
    }

    public void setAndar(int andar) {
        this.andar = andar;
    }

    public boolean getGaragem() {
        return garagem;
    }

    public void setGaragem(boolean garagem) {
        this.garagem = garagem;
    }

    public LojaHabitavel clone (){
        return new LojaHabitavel(this);
    }

    public boolean equals(Object o){
        if(o == this) return true;
        if(o == null || o.getClass()!= this.getClass()) return false;
        LojaHabitavel l = (LojaHabitavel) o;
        return super.equals(o) && garagem == l.getGaragem() && temWc == l.getTemWc() && andar == l.getAndar() && area == l.getArea()
                && areaTotal == l.getAreaTotal() && porta == l.getPorta() && quartos == l.getQuartos() && tipo.equals(l.getTipo())
                && tipoNegocio.equals(l.getTipoNegocio()) && wc == l.getQuantosWC();
    }
    public String toString(){
        StringBuilder str = new StringBuilder();

        str.append(super.toString()+ ", ");
        str.append(tipo+ ", ");
        str.append(Double.toString(areaTotal)+ ", ");
        str.append(Integer.toString(quartos)+ ", ");
        str.append(String.valueOf(wc)+ ", ");
        str.append(Integer.toString(porta)+ ", ");
        str.append(Integer.toString(andar)+ ", ");
        str.append(String.valueOf(garagem));

        return str.toString();


    }
    
    public void geraIdentificador(){
        int hash = 1;
        
        int valor = super.getEmailVendedor().hashCode();
        //valor+=String.valueOf(super.getEstado()).hashCode();
        
        //Preço minimo
        long p = Double.doubleToLongBits(super.getPrecoMinimo());
        valor +=(int) (p^(p>>>32));
        
        //Preço pedido
        
        p = Double.doubleToLongBits(super.getPrecoPedido());
        valor +=(int) (p^(p>>>32));
        
        //Rua
        
        valor+=super.getRua().hashCode();
        
        //parte de loja
        
        p = Double.doubleToLongBits(area);
        valor +=(int) (p^(p>>>32));

        valor+=tipoNegocio.hashCode();
        
        if(temWc) valor+=0;
        else valor+=1;
        
        valor+=andar;
        
        p = Double.doubleToLongBits(areaTotal);
        valor +=(int) (p^(p>>>32));
        
        if(garagem) valor+=0;
        else valor+=1;
        
        valor+=porta;
        valor+=quartos;
        valor+=tipo.hashCode();
        valor+=wc;
        
        hash = 37*hash+valor;
        
        super.setIdentificador(hash+"");
    }
}
