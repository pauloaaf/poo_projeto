package Imob;

import java.util.Date;
import java.util.Calendar;
import java.util.Comparator;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.io.Serializable;
/**
 * Write a description of class Consulta here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Consulta implements Comparable<Consulta>, Serializable{
  private DateFormat formato = new SimpleDateFormat("dd/MM/YY, HH:mm ");
  private Date data; 
  private String idImovel; //imovel consultado
  private String email;
  private static final long serialVersionUID = 1L;
  
  public Consulta(){
    data = new Date(); 
    email=null;
  }
  public Consulta(String idImovel){
    data = new Date();
    this.idImovel = idImovel;
    email = null;
  }
  
  public Consulta(String email,String idImovel){
      data = new Date();
      this.email = email;
      this.idImovel = idImovel;
      
    }
  public Consulta(Consulta c){
    data= c.getData();
    email=c.getEmail();
    idImovel = c.getIdImovel();
    }
    
  public String getIdImovel(){
      return idImovel;
  }
  
  public void setIdImovel(String id){
      idImovel = id;
    }
  public Consulta(Date c , String email){
    data = c;
    this.email=email;
    }
    public void setData(Date c){data = c; }
    
    public void setEmail(String email){this.email=email;}
    
    public Date getData(){
        return data;
    }
    public String getEmail(){return email;}                                                                
    
    public void atualizaData(){
        data= new Date();
    }
    
    public Consulta clone(){
        return new Consulta(this);
    }
    
    public boolean equals(Object o){
        if(o == this) return true;
        if(o == null || o.getClass()!= this.getClass()) return false;
        Consulta c = (Consulta) o;
        
        return data.equals(c.getData()) && email.equals(c.getEmail());
    }
    
    public String toString(){
        StringBuilder str = new StringBuilder();
        
        str.append(formato.format(data) + " "); 
        str.append(email);
        
        return str.toString();
        
    } 
    
    public int compareTo(Consulta c){
        if(this.getData().before(c.getData())){
            return 1;
        }
       if(this.getData().after(c.getData())){
           return -1;
       }
       return 0;
    }
}
