package Imob;
/**
 * Write a description of class ComparatorImovel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.Comparator;

public class ComparatorImovelPreco implements Comparator<Imovel>{
    
    public int compare(Imovel im1, Imovel im2){
        if(im1.getPrecoPedido()<im2.getPrecoPedido()) return -1;
        if(im1.getPrecoPedido()>im2.getPrecoPedido()) return 1;
        return 0;
    }
}
