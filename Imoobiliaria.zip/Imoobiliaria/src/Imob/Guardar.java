/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Imob;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author paulo
 */
public class Guardar {
    public static void gravaImoobiliaria(Imoobiliaria im) throws IOException{

       ObjectOutputStream save = new ObjectOutputStream(new FileOutputStream("/home/paulo/projeto/Imoobiliaria")); 
       save.writeObject(im);
       save.flush();
       save.close();
    }
    
    /**
     * Ler a classe imoobiliaria dos ficheiros
     */
    
    public static Imoobiliaria leImoobiliaria(){
        Imoobiliaria im = new Imoobiliaria();
        try{
            FileInputStream file = new FileInputStream("/home/paulo/projeto/Imoobiliaria");
            ObjectInputStream ler = new ObjectInputStream(file);
            im = (Imoobiliaria) ler.readObject();
            ler.close();
            file.close();
        }catch(FileNotFoundException exc){
            System.out.println("Ficheiro nao encontrado!");
        }catch(IOException exc){
            //System.out.println("IOException!");
            exc.printStackTrace();
        }catch(ClassNotFoundException exc){
            System.out.println("Classe nao encontrada!");
        }
        
        return im;
    }
}
