package Imob;

public class Loja extends Imovel{
	
    private double area;
    private boolean wc;
    private String tipoNegocio;
    private int porta;
    
    //Construtor Loja
    
    public Loja(){
		super();
		this.area = 0;
		this.wc = false;
		this.tipoNegocio = "N/A";
		this.porta =0;
		geraIdentificador();
		
	}
	
	 // Para parte habitacional - informa��o guardada para os apartamentos
	// construtor loja
    public Loja(String rua, double precoPedido, double precoMinimo, EstadoImovel estado,String email, double area, boolean wc, String tipoNegocio, int porta) {
    	super(rua,precoPedido,precoMinimo,estado,email);
    	this.area = area;
    	this.wc = wc;
    	this.tipoNegocio = tipoNegocio;
    	this.porta = porta;
    	geraIdentificador();
    }
    
    public Loja(Loja l) {
    	this(l.getRua(),l.getPrecoPedido(),l.getPrecoMinimo(), l.getEstado(),l.getEmailVendedor(), l.getArea(),l.getWc(),l.getTipoNegocio(),l.getPorta());
    }
    
    //get e set loja
    
	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	public boolean getWc() {
		return wc;
	}

	public void setWc(boolean wc) {
		this.wc = wc;
	}

	public String getTipoNegocio() {
		return tipoNegocio;
	}

	public void setTipoNegocio(String tipoNegocio) {
		this.tipoNegocio = tipoNegocio;
	}

	public int getPorta() {
		return porta;
	}

	public void setPorta(int porta) {
		this.porta = porta;
	}

    
    public Loja clone(){
    	return new Loja(this);
    }
    
    public boolean equals(Object o){
    	if(o == this) return true;
		if(o == null || o.getClass()!= this.getClass()) return false;
		Loja loja = (Loja) o;
		
		return super.equals(o) && wc == loja.getWc() && area == loja.getArea() && tipoNegocio.equals(loja.getTipoNegocio()) && porta == loja.getPorta();
    }
    
    public String toString(){
    	StringBuilder str = new StringBuilder();
    	
    	str.append(super.toString() + ", ");
    	str.append(Double.toString(area) + ", ");
    	str.append(String.valueOf(wc) +", ");
    	str.append(tipoNegocio + ", ");
    	str.append(Integer.toString(porta));
    	
    	return str.toString();
    	
    }
   
    public void geraIdentificador(){
        int hash = 1;
        
        int valor = super.getEmailVendedor().hashCode();
        //valor+=String.valueOf(super.getEstado()).hashCode();
        
        //Preço minimo
        long p = Double.doubleToLongBits(super.getPrecoMinimo());
        valor +=(int) (p^(p>>>32));
        
        //Preço pedido
        
        p = Double.doubleToLongBits(super.getPrecoPedido());
        valor +=(int) (p^(p>>>32));
        
        //Rua
        
        valor+=super.getRua().hashCode();
        
        //parte de loja
        
        p = Double.doubleToLongBits(area);
        valor +=(int) (p^(p>>>32));
        
        valor+=porta;
        valor+=tipoNegocio.hashCode();
        
        if(wc) valor+=0;
        else valor+=1;
        
        hash = 37*hash + valor;
        
        super.setIdentificador(hash+"");
    }
    
}




