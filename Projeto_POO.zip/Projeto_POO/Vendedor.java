 

import java.util.Set;  
import java.util.TreeSet;


public class Vendedor extends Utilizador {

    private Set<Imovel> vender; 
    private Set<Imovel> vendidos; 
    
    public Vendedor(){
        super();
        vender=new TreeSet<Imovel>(); 
        vendidos= new TreeSet<Imovel>(); 
    }
    
    public Vendedor(Vendedor a){
        super(a.getEmail(),a.getNome(),a.getPassword(),a.getData(),a.getMorada());
        this.vender = a.getVender(); 
        this.vendidos = a.getVendidos();
    }
    
    public Vendedor(String email, String nome, String password, String data,String morada){
        super(email,nome,password,data,morada);
        vender = new TreeSet<>();
        vendidos = new TreeSet<>();
    }

    public Vendedor(Set<Imovel>vender , Set<Imovel> vendidos){
        this();
        setVender(vender);
        setVendidos(vendidos);
    }
    
    public Set<Imovel> getVender(){ 
        Set<Imovel> res = new TreeSet<Imovel>(); 
        for(Imovel im: vender){
            res.add(im.clone());
        } 
            
        return res;
    }
    
    public Set<Imovel> getVendidos(){ 
        Set<Imovel> res = new TreeSet<Imovel>(); 
        for(Imovel im: vendidos){
            res.add(im.clone());
        } 
            
        return res;
    }
    
    public void setVender(Set<Imovel> vender){
        this.vender.clear(); 
        for(Imovel im: vender){ 
            this.vender.add(im.clone());
        }
    }
    
    public void setVendidos(Set<Imovel> vendidos){
        this.vendidos.clear(); 
        for(Imovel im: vendidos){ 
            this.vendidos.add(im.clone());
        }
    }
    
            
      public String toString(){ 
          StringBuilder sb= new StringBuilder();
          for(Imovel a: vender){
              sb.append(a.toString());
          } 
          for(Imovel c: vendidos){
              sb.append(c.toString());
          } 
              return sb.toString();
      }
            
      public Vendedor clone(){
          return new Vendedor(this); 
      }
      
      public Utilizador copia(){
          return (Utilizador) new Vendedor(this);
      }
}
