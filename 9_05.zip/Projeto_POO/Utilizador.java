 

/**
 * 
 * @author paulo
 * Classe para criar um vendedor ou um comprador
 *
 */
import java.util.Comparator;
import java.io.*;

public class Utilizador implements Comparable<Utilizador>, Serializable{
    private String email; 
    private String nome;
    private String password;
    private String morada;
    private String data; //data de nascimento
    //private int tipo; //define se o utilizador é um vendedor ou um comprador: 
                            // 0 se for vendedor
                            // 1 se for comprador

    
    public Utilizador(String email, String nome, String password,String morada,String data) {
        this.email = email;
        this.nome = nome;
        this.password = password;
        this.data = data;
        this.morada = morada;
    }
    
    public Utilizador(Utilizador u){
        this(u.getEmail(),u.getNome(),u.getPassword(),u.getMorada(),u.getData());
    }
    
    public Utilizador(){
        this.email = "N/A";
        this.nome = "N/A";
        this.password = "N/A";
        this.morada = "N/A";
        this.data = "N/A";
    }
    
    public String getEmail(){return email;}
    public String getNome(){return nome;}
    public String getPassword(){return password;}
    public String getData(){return data;}
    public String getMorada(){return morada;}
    public void setEmail(String email){this.email = email;}
    public void setNome(String nome){this.nome = nome;}
    public void setPassword(String password){this.password = password;}
    public void setData(String data){this.data = data;}     
    public void setMorada(String morada){}
    
    //public abstract Utilizador copia();
    
    public Utilizador clone(){
        return new Utilizador(this);
    }
    
    public boolean equals(Object o){
        if(o == this) return true;
        if(o.getClass() != this.getClass()) return false;
        Utilizador n = (Utilizador) o;
        return n.getData() == this.getData() && n.getEmail() == this.getEmail() && n.getMorada() == this.getMorada()
            && n.getNome() == this.getNome() && n.getPassword() == this.getPassword();
    }
    
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append(email).append(" ").append(nome).append(" ").append(password).append(" ").append(morada).append(" ").append(data);
        return sb.toString();
    }
   
    public int compareTo(Utilizador u){
        return this.getEmail().compareTo(u.getEmail());
    }
}


