 

import java.util.Map;
import java.util.TreeMap;
import java.lang.StringBuilder;
import java.io.Serializable;

public class Comprador extends Utilizador {
    private Map<String,Imovel> favoritos;
    
    public Comprador(String email, String nome, String password, String data, String morada){
        super(email,nome,password,data,morada);
        favoritos = new TreeMap<>();
    }
    
    public Comprador(Comprador c){
        super(c.getEmail(),c.getNome(),c.getPassword(),c.getData(),c.getMorada());
        favoritos = c.getFavorito();
    }
    
    public Comprador(){
        super();
        favoritos = new TreeMap<>();
    }
    
    public Map<String,Imovel> getFavorito(){
        Map<String,Imovel> res = new TreeMap<>();
        for(Imovel im:favoritos.values()){
            res.put(im.getIdentificador(),im.clone());
        }
        return res;
    }
    
    public void setFavoritos(Map<String,Imovel> s){
        favoritos.clear();
        for(Imovel im:s.values()){
            favoritos.put(im.getIdentificador(),im.clone());
        }
    }
    
    public String toString(){
        StringBuilder s = new StringBuilder();
        for(Imovel im:favoritos.values()){
            s.append(im.toString());
            s.append(", ");
        }
        return s.toString();
    }
    
    /**
     * Acrescenta um imovel aos favoritos
     */
    
    public void favorito(Imovel im)
        throws ImovelFavoritoException{
        
        if(favoritos.containsKey(im.getIdentificador()))
            throw new ImovelFavoritoException("Imovel ja adicionado aos favoritos!");
        else
            favoritos.put(im.getIdentificador(),im.clone());
    }
    
    public boolean equals(Object o){
        
        if(o == this) return true;
        if(o == null || o.getClass() != this.getClass()) return false;
        Comprador c = (Comprador) o;
        if(this.getFavorito().size() != c.getFavorito().size())
            return false;
        
        for(String s:favoritos.keySet()){
            if(!c.getFavorito().containsKey(s)) return false;
        }
        return true;
    }
    
    public Comprador clone(){
        return new Comprador(this);
    }
    
    public Utilizador copia(){
        return (Utilizador) new Comprador(this);
    }
}
